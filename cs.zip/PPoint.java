package kr.ac.kookmin.cs;
/**
   @version 1.01 2004-02-21
   @author Cay Horstmann
*/    
public class PPoint {
    int xA;
    int yA;



public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
/**
   @return xA 
*/
    public int getX() {
        return xA;
    }
/**
   @return yA 
*/
    public int getY() {
        return yA;
    }
}
